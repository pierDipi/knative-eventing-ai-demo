# ALBERT (ALBERT: A Lite BERT for Self-supervised Learning of Language Representations)

**WARNING**: This directory is deprecated.
See `nlp/docs/MODEL_GARDEN.md` for the new ALBERT implementation.
